package pkgMain;

public class cMain {

	public static void main(String[] args) {

		Rectangle rec = new Rectangle(1.5, 2.5);		
		System.out.println("Rectangle Area: " + rec.Area());
	}

}
